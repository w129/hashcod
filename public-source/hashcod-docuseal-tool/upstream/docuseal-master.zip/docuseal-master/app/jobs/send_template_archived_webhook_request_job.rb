# frozen_string_literal: true

class SendTemplateArchivedWebhookRequestJob
  include Sidekiq::Job

  sidekiq_options queue: :webhooks

  MAX_ATTEMPTS = 10

  def perform(params = {})
    template = Template.find_by(id: params['template_id'])

    return unless template

    webhook_url = WebhookUrl.find_by(id: params['webhook_url_id'])

    return unless webhook_url

    attempt = params['attempt'].to_i

    return if webhook_url.url.blank? || webhook_url.events.exclude?('template.archived')

    resp = SendWebhookRequest.call(webhook_url, event_type: 'template.archived',
                                                event_uuid: params['event_uuid'],
                                                record: template,
                                                attempt:,
                                                data: template.as_json(only: %i[id archived_at]))

    return if attempt > MAX_ATTEMPTS || (resp && resp.status.to_i < 400)

    SendTemplateArchivedWebhookRequestJob.perform_in((2**attempt).minutes, {
                                                       **params,
                                                       'attempt' => attempt + 1,
                                                       'last_status' => resp&.status.to_i
                                                     })
  end
end
